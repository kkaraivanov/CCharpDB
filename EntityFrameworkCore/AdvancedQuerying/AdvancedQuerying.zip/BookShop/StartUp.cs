﻿namespace BookShop
{
    using System;
    using System.Linq;
    using System.Reflection.Metadata.Ecma335;
    using System.Text;
    using Data;
    using Initializer;
    using Initializer.Managment;
    using Models.Enums;

    public class StartUp
    {
        static void Main()
        {
            using var db = new BookShopContext();
            //DbInitializer.ResetDatabase(db);
            
            try
            {
                Console.WriteLine(GetBooksByPrice(db));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public static string GetBooksByPrice(BookShopContext context)
        {
            var sb = new StringBuilder();
            var books = context
                .Books
                .Where(x => x.Price > 40)
                .OrderByDescending(x => x.Price)
                .Select(x => new {x.Title, x.Price})
                .ToList();

            foreach (var book in books)
            {
                sb.AppendLine($"{book.Title} - ${book.Price:f2}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
