﻿namespace PetSore.Services.Interfaces
{
    using PetStore.Data;

    public interface IPetStore
    {
        
    }
}