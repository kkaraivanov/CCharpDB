﻿namespace PetStore.Services.Model.Distributor
{
    public class Distributors
    {
        internal int Id { get; set; }

        public string Name { get; set; }

        public string BankAccount { get; set; }
    }
}