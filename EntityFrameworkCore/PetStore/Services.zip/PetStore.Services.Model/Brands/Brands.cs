﻿namespace PetStore.Services.Model.Brands
{
    public class Brands
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
