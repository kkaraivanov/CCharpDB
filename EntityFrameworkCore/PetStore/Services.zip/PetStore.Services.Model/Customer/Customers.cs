﻿namespace PetStore.Services.Model.Customer
{
    public class Customers
    {
        public string FirstName { get; set; }

        public string LasttName { get; set; }

        public string Email { get; set; }

        public int PhoneNumber { get; set; }
    }
}