﻿namespace PetSore.Data.Common.Enumerators
{
    public enum OrderStatus
    {
        Paid = 0,
        Pending = 1,
        Done = 2
    }
}