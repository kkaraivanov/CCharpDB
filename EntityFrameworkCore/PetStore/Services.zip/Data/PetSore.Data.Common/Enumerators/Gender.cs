﻿namespace PetSore.Data.Common.Enumerators
{
    public enum Gender
    {
        Male = 0,
        Female = 1
    }
}