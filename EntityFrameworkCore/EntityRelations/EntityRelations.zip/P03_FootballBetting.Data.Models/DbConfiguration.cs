﻿namespace P03_FootballBetting.Data
{
    internal static class DbConfiguration
    {
        internal static string ConnectionString =>
            "Server=.\\SQLKARAIVANOV;Database=FootballBookmakerSystem;Integrated Security=True;";
    }
}